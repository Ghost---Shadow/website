mkdir extracted_files
gpg --batch --passphrase "your-password" -d archive.tar.gz.gpg | tar xzf - -C extracted_files/
